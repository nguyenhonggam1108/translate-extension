chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension installed and ready to use!");
});
