document.getElementById('translateBtn').addEventListener('click', async function() {
  const inputText = document.getElementById('inputText').value;
  if (inputText.trim() === "") {
    alert("Vui lòng nhập văn bản cần dịch!.");
    return;
  }

  // Lấy ngôn ngữ nguồn và ngôn ngữ đích từ dropdown
  const sourceLang = document.getElementById('sourceLang').value;
  const targetLang = document.getElementById('targetLang').value;

  // Gọi API dịch ngôn ngữ
  const translation = await translateText(inputText, sourceLang, targetLang);
  document.getElementById('outputText').value = translation;
});

async function translateText(text, sourceLang, targetLang) {
  const url = `https://api-inference.huggingface.co/models/Helsinki-NLP/opus-mt-${sourceLang}-${targetLang}`;
  const headers = {
    'Authorization': 'Bearer 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',
    'Content-Type': 'application/json',
  };
  const body = JSON.stringify({
    inputs: text
  });

  const response = await fetch(url, {
    method: 'POST',
    headers: headers,
    body: body
  });
  //Chuyển đổi phản hồi từ API thành đối tượng JSON.
  const data = await response.json();

  // Kiểm tra nếu kết quả trả về có trường translation_text
  if (data && data[0] && data[0].translation_text) {
    return data[0].translation_text; // Trả về kết quả dịch
  } else {
    return 'Đã xảy ra lỗi trong quá trình dịch.';
  }
}
